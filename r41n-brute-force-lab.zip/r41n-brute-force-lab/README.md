# R41N Brute Force Lab

A beginner-friendly Python cybersecurity portfolio project that demonstrates password-guessing concepts in a **local-only toy simulation**.

## Safety scope

- Does not connect to the internet or send requests.
- Does not interact with real login pages, accounts, or services.
- Uses a small numeric candidate space (1–5 digits) for demonstration only.
- Use only for learning and authorized security work.

## Requirements

- Python 3.10 or newer
- No third-party packages required

## Run it

```bash
python3 brute_force_lab.py
```

Try a different three-digit toy secret:

```bash
python3 brute_force_lab.py --secret 731 --length 3
```

Try a password-strength tip check (the text is not saved):

```bash
python3 brute_force_lab.py --check-password 'password123'
```

## Run tests

```bash
python3 -m unittest discover -s tests -v
```

## What this demonstrates

- Python functions, generators, command-line arguments, and dataclasses
- SHA-256 hashing for illustrating candidate comparison (not password storage guidance)
- Basic timing and attempt counting
- Unit testing and clear safety boundaries

**Important:** SHA-256 by itself is not appropriate for storing real user passwords. Production systems should use a dedicated password-hashing algorithm such as Argon2id, scrypt, or bcrypt with suitable parameters and salts.

## Possible next improvements

1. Add a CSV report for simulation results.
2. Compare search-space sizes for different password lengths.
3. Add a lockout/rate-limit model to demonstrate defensive controls.
4. Improve password feedback with a documented scoring rubric.

## Resume example

**R41N Brute Force Lab | Python, Cybersecurity, Unit Testing**
- Built a local-only Python password-guessing simulator to explore search spaces, hashing, attempt counts, and runtime.
- Added command-line options, password feedback, and automated unit tests.
- Documented ethical-use boundaries and explained why production password storage requires purpose-built password hashing.

Only list features you have personally run and can explain in an interview.
