import unittest
from brute_force_lab import audit_demo_secret, generate_numeric_candidates, password_feedback


class BruteForceLabTests(unittest.TestCase):
    def test_candidates_are_zero_padded(self):
        self.assertEqual(list(generate_numeric_candidates(2))[:3], ["00", "01", "02"])

    def test_finds_toy_secret(self):
        result = audit_demo_secret("07", generate_numeric_candidates(2))
        self.assertTrue(result.found)
        self.assertEqual(result.candidate, "07")
        self.assertEqual(result.attempts, 8)

    def test_missing_secret(self):
        result = audit_demo_secret("not-in-list", ["00", "01"])
        self.assertFalse(result.found)
        self.assertIsNone(result.candidate)

    def test_rejects_large_demo_space(self):
        with self.assertRaises(ValueError):
            list(generate_numeric_candidates(6))

    def test_password_feedback(self):
        self.assertTrue(password_feedback("123456"))


if __name__ == "__main__":
    unittest.main()
