#!/usr/bin/env python3
"""R41N Brute Force Lab: a local-only password guessing simulator.

This educational demo never connects to a network, website, or real account.
It only tests a toy secret entered for the local simulation.
"""
from __future__ import annotations

import argparse
import hashlib
import time
from dataclasses import dataclass


@dataclass
class AuditResult:
    found: bool
    attempts: int
    elapsed_seconds: float
    candidate: str | None


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def generate_numeric_candidates(length: int):
    """Yield zero-padded numeric guesses, from 0 through 10**length - 1."""
    if not 1 <= length <= 5:
        raise ValueError("Demo length must be between 1 and 5 digits.")
    for number in range(10**length):
        yield f"{number:0{length}d}"


def audit_demo_secret(secret: str, candidates) -> AuditResult:
    """Compare guesses against a hash for a local demo secret."""
    target_hash = sha256_text(secret)
    attempts = 0
    started = time.perf_counter()
    for candidate in candidates:
        attempts += 1
        if sha256_text(candidate) == target_hash:
            return AuditResult(True, attempts, time.perf_counter() - started, candidate)
    return AuditResult(False, attempts, time.perf_counter() - started, None)


def password_feedback(password: str) -> list[str]:
    """Give simple educational feedback; this is not a full password meter."""
    tips = []
    if len(password) < 12:
        tips.append("Use at least 12 characters; longer is generally better.")
    if password.lower() in {"password", "letmein", "qwerty", "123456", "admin"}:
        tips.append("Avoid common passwords and predictable patterns.")
    if password.isalpha() or password.isdigit():
        tips.append("Avoid using only letters or only digits.")
    if not tips:
        tips.append("Good start. Prefer a unique passphrase and use a password manager.")
    return tips


def main() -> None:
    parser = argparse.ArgumentParser(description="Local-only brute-force learning lab")
    parser.add_argument("--secret", default="042", help="Toy numeric secret for the demo (default: 042)")
    parser.add_argument("--length", type=int, default=3, help="Number of digits to try (1-5; default: 3)")
    parser.add_argument("--check-password", help="Show basic advice for a password you provide")
    args = parser.parse_args()

    if args.check_password is not None:
        print("Password tips:")
        for tip in password_feedback(args.check_password):
            print(f"- {tip}")
        return

    if not args.secret.isdigit() or len(args.secret) != args.length:
        parser.error("--secret must contain exactly --length numeric digits.")
    if not 1 <= args.length <= 5:
        parser.error("--length must be between 1 and 5 for this local demo.")

    print("R41N Brute Force Lab — LOCAL SIMULATION ONLY")
    print("No network requests or real accounts are used.\n")
    result = audit_demo_secret(args.secret, generate_numeric_candidates(args.length))
    print(f"Result: {'MATCH FOUND' if result.found else 'NO MATCH'}")
    print(f"Attempts: {result.attempts:,}")
    print(f"Elapsed: {result.elapsed_seconds:.6f} seconds")
    if result.found:
        print(f"Demo guess: {result.candidate}")
    print("\nSecurity lesson: longer, unique passwords increase the search space.")


if __name__ == "__main__":
    main()
